#ifndef CHESSLIB_H
#define CHESSLIB_H
 struct poz {
    short yatay;
    char dusey;

};
void hareketYazdir(char tas, struct poz ilkPozisyon);


#endif // CHESSLIB_H
